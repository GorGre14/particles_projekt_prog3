#!/usr/bin/env python3
"""
Generate line charts for ChargedParticles performance analysis
Shows execution time comparison between Sequential, Parallel, and Distributed modes
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

def create_performance_charts():
    """Create line charts showing performance comparison"""
    
    # Read the CSV files
    try:
        fixed_particles_df = pd.read_csv('fixed_particles_results.csv')
        fixed_cycles_df = pd.read_csv('fixed_cycles_results.csv')
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure the CSV files are in the current directory")
        return
    
    # Set up the plotting style
    plt.style.use('default')
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # Colors for each mode
    colors = {
        'sequential': '#1f77b4',  # Blue
        'parallel': '#ff7f0e',    # Orange  
        'distributed': '#2ca02c'  # Green
    }
    
    # Chart 1: Fixed Particles (3000), Increasing Cycles
    print("Creating Chart 1: Fixed Particles Performance...")
    
    modes_data_1 = {}
    for mode in ['sequential', 'parallel', 'distributed']:
        mode_data = fixed_particles_df[fixed_particles_df['mode'] == mode].copy()
        if not mode_data.empty:
            modes_data_1[mode] = mode_data.sort_values('cycles')
    
    for mode, data in modes_data_1.items():
        ax1.plot(data['cycles'], data['average_time'], 
                marker='o', linewidth=2.5, markersize=6,
                color=colors[mode], label=f'{mode.capitalize()} Mode')
        
        # Add error bars
        ax1.errorbar(data['cycles'], data['average_time'], 
                    yerr=data['std_dev'], fmt='none', 
                    color=colors[mode], alpha=0.5, capsize=3)
    
    ax1.set_xlabel('Number of Cycles', fontsize=12)
    ax1.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax1.set_title('Test 1: Fixed Particles (3000)\nPerformance vs Cycles', fontsize=14, fontweight='bold')
    ax1.grid(True, alpha=0.3)
    ax1.legend(fontsize=11)
    
    # Add speedup annotations for parallel mode
    if 'parallel' in modes_data_1 and 'sequential' in modes_data_1:
        seq_data = modes_data_1['sequential']
        par_data = modes_data_1['parallel']
        
        # Find common cycles for speedup calculation
        common_cycles = set(seq_data['cycles']).intersection(set(par_data['cycles']))
        if common_cycles:
            sample_cycle = min(common_cycles)
            seq_time = seq_data[seq_data['cycles'] == sample_cycle]['average_time'].iloc[0]
            par_time = par_data[par_data['cycles'] == sample_cycle]['average_time'].iloc[0]
            speedup = seq_time / par_time
            
            ax1.annotate(f'Speedup: {speedup:.1f}x',
                        xy=(sample_cycle, par_time), 
                        xytext=(sample_cycle + 1000, par_time + 20),
                        arrowprops=dict(arrowstyle='->', color='red', alpha=0.7),
                        fontsize=10, color='red', fontweight='bold')
    
    # Chart 2: Fixed Cycles (10000), Increasing Particles
    print("Creating Chart 2: Fixed Cycles Performance...")
    
    modes_data_2 = {}
    for mode in ['sequential', 'parallel', 'distributed']:
        mode_data = fixed_cycles_df[fixed_cycles_df['mode'] == mode].copy()
        if not mode_data.empty:
            modes_data_2[mode] = mode_data.sort_values('particles')
    
    for mode, data in modes_data_2.items():
        ax2.plot(data['particles'], data['average_time'], 
                marker='s', linewidth=2.5, markersize=6,
                color=colors[mode], label=f'{mode.capitalize()} Mode')
        
        # Add error bars
        ax2.errorbar(data['particles'], data['average_time'], 
                    yerr=data['std_dev'], fmt='none', 
                    color=colors[mode], alpha=0.5, capsize=3)
    
    ax2.set_xlabel('Number of Particles', fontsize=12)
    ax2.set_ylabel('Execution Time (seconds)', fontsize=12)
    ax2.set_title('Test 2: Fixed Cycles (10000)\nPerformance vs Particles', fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    ax2.legend(fontsize=11)
    
    # Add speedup annotation for parallel mode
    if 'parallel' in modes_data_2 and 'sequential' in modes_data_2:
        seq_data = modes_data_2['sequential']
        par_data = modes_data_2['parallel']
        
        # Find common particles for speedup calculation
        common_particles = set(seq_data['particles']).intersection(set(par_data['particles']))
        if common_particles:
            sample_particles = min(common_particles)
            seq_time = seq_data[seq_data['particles'] == sample_particles]['average_time'].iloc[0]
            par_time = par_data[par_data['particles'] == sample_particles]['average_time'].iloc[0]
            speedup = seq_time / par_time
            
            ax2.annotate(f'Speedup: {speedup:.1f}x',
                        xy=(sample_particles, par_time), 
                        xytext=(sample_particles + 200, par_time + 5),
                        arrowprops=dict(arrowstyle='->', color='red', alpha=0.7),
                        fontsize=10, color='red', fontweight='bold')
    
    # Improve layout
    plt.tight_layout()
    
    # Save the chart
    output_file = 'performance_comparison_charts.png'
    plt.savefig(output_file, dpi=300, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    print(f"\nCharts saved to: {output_file}")
    
    # Show summary statistics
    print("\n" + "="*60)
    print("PERFORMANCE SUMMARY")
    print("="*60)
    
    # Test 1 Summary
    if 'sequential' in modes_data_1 and 'parallel' in modes_data_1:
        seq_times = modes_data_1['sequential']['average_time']
        par_times = modes_data_1['parallel']['average_time']
        
        print(f"\nTest 1 (Fixed 3000 particles):")
        print(f"  Sequential range: {seq_times.min():.1f}s - {seq_times.max():.1f}s")
        print(f"  Parallel range:   {par_times.min():.1f}s - {par_times.max():.1f}s")
        
        # Calculate average speedup where both modes have data
        speedups = []
        seq_data = modes_data_1['sequential']
        par_data = modes_data_1['parallel']
        for _, seq_row in seq_data.iterrows():
            par_row = par_data[par_data['cycles'] == seq_row['cycles']]
            if not par_row.empty:
                speedup = seq_row['average_time'] / par_row['average_time'].iloc[0]
                speedups.append(speedup)
        
        if speedups:
            print(f"  Average speedup:  {np.mean(speedups):.2f}x")
            print(f"  Best speedup:     {max(speedups):.2f}x")
    
    # Test 2 Summary  
    if 'sequential' in modes_data_2 and 'parallel' in modes_data_2:
        seq_times = modes_data_2['sequential']['average_time']
        par_times = modes_data_2['parallel']['average_time']
        
        print(f"\nTest 2 (Fixed 10000 cycles):")
        print(f"  Sequential range: {seq_times.min():.1f}s - {seq_times.max():.1f}s")
        print(f"  Parallel range:   {par_times.min():.1f}s - {par_times.max():.1f}s")
        
        # Calculate average speedup where both modes have data
        speedups = []
        seq_data = modes_data_2['sequential']
        par_data = modes_data_2['parallel']
        for _, seq_row in seq_data.iterrows():
            par_row = par_data[par_data['particles'] == seq_row['particles']]
            if not par_row.empty:
                speedup = seq_row['average_time'] / par_row['average_time'].iloc[0]
                speedups.append(speedup)
        
        if speedups:
            print(f"  Average speedup:  {np.mean(speedups):.2f}x")
            print(f"  Best speedup:     {max(speedups):.2f}x")
    
    # Distributed mode summary
    distributed_1 = modes_data_1.get('distributed')
    distributed_2 = modes_data_2.get('distributed')
    
    if distributed_1 is not None or distributed_2 is not None:
        print(f"\nDistributed Mode:")
        if distributed_1 is not None:
            print(f"  Test 1 successful runs: {len(distributed_1)}")
        if distributed_2 is not None:
            print(f"  Test 2 successful runs: {len(distributed_2)}")
        print(f"  Status: Limited by timeout constraints")
    
    print("\n" + "="*60)
    
    plt.show()

if __name__ == "__main__":
    create_performance_charts()