# ChargedParticles Performance Test Results (Partial)

## Test Configuration
- **Test 1**: Fixed 3000 particles, increasing cycles (500 → 10000, increment 500)
- **Runs per configuration**: 3
- **Max runtime threshold**: 180 seconds
- **Date**: 2025-07-29

## Results Summary

### Sequential Mode Performance
| Particles | Cycles | Avg Time (s) | Std Dev (s) | Speedup vs Sequential |
|-----------|--------|--------------|-------------|----------------------|
| 3000 | 500 | 7.975 | 0.201 | 1.00x |
| 3000 | 1000 | 16.075 | 0.183 | 1.00x |
| 3000 | 1500 | 24.025 | 0.100 | 1.00x |
| 3000 | 2000 | 32.216 | 0.343 | 1.00x |
| 3000 | 2500 | 39.301 | 1.372 | 1.00x |
| 3000 | 3000 | 48.194 | 0.198 | 1.00x |
| 3000 | 3500 | 55.005 | 1.871 | 1.00x |
| 3000 | 4000 | 64.429 | 0.964 | 1.00x |
| 3000 | 4500 | 72.734 | 0.591 | 1.00x |
| 3000 | 5000 | 80.588 | 0.101 | 1.00x |
| 3000 | 5500 | 88.097 | 0.209 | 1.00x |
| 3000 | 6000 | 96.285 | 0.200 | 1.00x |
| 3000 | 6500 | 102.529 | 3.502 | 1.00x |
| 3000 | 7000 | 112.943 | 0.248 | 1.00x |
| 3000 | 7500 | 121.516 | 1.193 | 1.00x |
| 3000 | 8000 | 130.932 | 3.227 | 1.00x |
| 3000 | 8500 | 144.946 | 15.055 | 1.00x |
| 3000 | 9000 | 146.030 | 0.609 | 1.00x |
| 3000 | 9500 | 156.707 | 3.163 | 1.00x |
| 3000 | 10000 | 160.789 | 0.471 | 1.00x |

### Parallel Mode Performance
| Particles | Cycles | Avg Time (s) | Std Dev (s) | Speedup vs Sequential |
|-----------|--------|--------------|-------------|----------------------|
| 3000 | 500 | 2.067 | 0.157 | **3.86x** |
| 3000 | 1000 | 4.552 | 0.217 | **3.53x** |
| 3000 | 1500 | 6.935 | 0.056 | **3.46x** |
| 3000 | 2000 | 11.656 | 1.351 | **2.76x** |
| 3000 | 2500 | 15.452 | 0.849 | **2.54x** |
| 3000 | 3000 | 18.198 | 0.582 | **2.65x** |
| 3000 | 3500 | 20.160 | 0.850 | **2.73x** |
| 3000 | 4000 | 22.743 | 0.398 | **2.83x** |
| 3000 | 4500 | 27.157 | 0.330 | **2.68x** |
| 3000 | 5000 | 28.854 | 0.433 | **2.79x** |
| 3000 | 5500 | 32.441 | 1.020 | **2.72x** |
| 3000 | 6000 | 36.441 | 1.262 | **2.64x** |
| 3000 | 6500 | 40.196 | 0.586 | **2.55x** |
| 3000 | 7000 | 42.849 | 2.113 | **2.64x** |
| 3000 | 7500 | 46.235 | 0.996 | **2.63x** |
| 3000 | 8000 | 48.006 | 0.576 | **2.73x** |
| 3000 | 8500 | 50.976 | 1.356 | **2.84x** |
| 3000 | 9000 | 55.530 | 0.946 | **2.63x** |
| 3000 | 9500 | 59.005 | 2.766 | **2.66x** |
| 3000 | 10000 | 59.649 | 2.416 | **2.70x** |

### Distributed Mode Performance (Partial - Test Failed)
| Particles | Cycles | Avg Time (s) | Std Dev (s) | Status |
|-----------|--------|--------------|-------------|---------|
| 3000 | 500 | 4.767 | 0.843 | ✅ Success |
| 3000 | 1000 | 11.851 | 0.244 | ✅ Success |
| 3000 | 1500 | 16.847 | 0.405 | ✅ Success |
| 3000 | 2000 | 23.623 | 3.357 | ✅ Success |
| 3000 | 2500 | 24.380 | 0.350 | ✅ Success |
| 3000 | 3000 | 29.311 | 0.000 | ⚠️ Partial (2/3 runs timeout) |
| 3000 | 3500+ | - | - | ❌ All runs timeout |

## Key Findings

### 1. Parallel Mode Shows Excellent Speedup
- **Average speedup**: 2.5x - 3.9x over sequential mode
- **Best performance**: 3.86x speedup for smaller workloads (500 cycles)
- **Consistent performance**: Maintains 2.5-2.8x speedup for larger workloads
- **Low variance**: Generally stable performance with small standard deviations

### 2. Linear Scaling with Problem Size
- **Sequential mode**: Shows linear relationship between cycles and runtime
- **Parallel mode**: Maintains roughly constant speedup ratio across different workload sizes
- **Scaling factor**: ~16ms per cycle for sequential, ~6ms per cycle for parallel

### 3. Performance Characteristics
- **Sequential baseline**: 7.975s (500 cycles) → 160.789s (10000 cycles)
- **Parallel improvement**: 2.067s (500 cycles) → 59.649s (10000 cycles)
- **Time savings**: Up to 101 seconds saved on largest workload (62% reduction)

### 4. Distributed Mode Issues
- **Initial success**: Worked well for smaller workloads (500-2500 cycles)
- **Timeout issues**: Failed on larger workloads due to 30s timeout limit
- **Network overhead**: Distributed mode slower than parallel for completed tests
- **Configuration**: Used 4 worker nodes

## Next Steps
1. Run dedicated distributed mode test with relaxed timeout settings
2. Investigate distributed mode performance characteristics
3. Complete Test 2 (Fixed cycles, increasing particles)
4. Analyze distributed mode network overhead vs computation benefits

## System Configuration
- **Java Version**: OpenJDK 21
- **Hardware**: Multi-core system (parallel mode shows good scaling)
- **Test Environment**: macOS Darwin 24.5.0
- **Worker Configuration**: 4 distributed worker nodes (when applicable)